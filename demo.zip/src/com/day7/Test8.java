package com.day7;

public class Test8 {

	public static void main(String[] args) {
		
		Lotto lt = new Lotto();
		
		lt.input();
		lt.pan();
		lt.print();
		
		
		

	}

}
