package com.calc;

public class NaverVO {
	
	
	
	private String checkid;
	private String checkpw;
	private String checkname;
	private String yearSel;
	private String monthSel;
	private String daySel;
	private String genSel;
	private String checkEmail;
	private String numSel;
	private String putPhoneNum;
	
	
	
	
	public String getCheckid() {
		return checkid;
	}
	public void setCheckid(String checkid) {
		this.checkid = checkid;
	}
	public String getCheckpw() {
		return checkpw;
	}
	public void setCheckpw(String checkpw) {
		this.checkpw = checkpw;
	}
	public String getCheckname() {
		return checkname;
	}
	public void setCheckname(String checkname) {
		this.checkname = checkname;
	}
	public String getYearSel() {
		return yearSel;
	}
	public void setYearSel(String yearSel) {
		this.yearSel = yearSel;
	}
	public String getMonthSel() {
		return monthSel;
	}
	public void setMonthSel(String monthSel) {
		this.monthSel = monthSel;
	}
	public String getDaySel() {
		return daySel;
	}
	public void setDaySel(String daySel) {
		this.daySel = daySel;
	}
	public String getGenSel() {
		return genSel;
	}
	public void setGenSel(String genSel) {
		this.genSel = genSel;
	}
	public String getCheckEmail() {
		return checkEmail;
	}
	public void setCheckEmail(String checkEmail) {
		this.checkEmail = checkEmail;
	}
	public String getNumSel() {
		return numSel;
	}
	public void setNumSel(String numSel) {
		this.numSel = numSel;
	}
	public String getPutPhoneNum() {
		return putPhoneNum;
	}
	public void setPutPhoneNum(String putPhoneNum) {
		this.putPhoneNum = putPhoneNum;
	}
	
	
	
	
	

}
