package com.day15;

public interface Bmi {
	
	
	public void input();
	public boolean searchNum(String num);
	public void print();
	public void delet();
	public void update();
	public void findnum();
	public void findName();

}
