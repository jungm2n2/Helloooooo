package com.score4;

public interface Score {
	
	public void input();
	public boolean searchHak(String hak);
	public void print();
	public void delete(); //�л�
	public void update(); //�л�
	public void findHak(); //�л�
	public void findName(); //�л�
	
	

}
