package com.score2;

public class Record {
	
	String hak,name;
	int kor,eng,mat;
	int tot,ave;
	

}
