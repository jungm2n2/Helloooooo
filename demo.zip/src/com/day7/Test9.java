package com.day7;

public class Test9 {

	public static void main(String[] args) {
		
		Odd od = new Odd();
		od.pan();
		od.print();
		
		

	}

}
