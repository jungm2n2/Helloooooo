package com.guest;

public class GuestDTO {
	
	private int num;
	private String name;
	private String email;
	private String homepage;
	private String content;
	private String created;
	private String ipAddr;
	
	
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
		
/*		
		if(homepage == null)
			this.homepage = "";
		else if(homepage.equalsIgnoreCase("http://"))
			this.homepage = "";
		else
		    this.homepage = homepage;
		
*/		
		
	}
	public String getHomepage() {
		return homepage;
	}
	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	
	
	
	
	
	

}
