package com.day7;

public class Test4 {

	public static void main(String[] args) {
		
		Totave ta = new Totave();
		
		ta.input();
		int t = ta.tot();
		int a = ta.ave();
		ta.print(t, a);
		
		

	}

}
