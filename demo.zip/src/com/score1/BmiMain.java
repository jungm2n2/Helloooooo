package com.score1;

public class BmiMain {

	public static void main(String[] args) {
		
		Bmi ob = new Bmi();
		
		ob.set();
		ob.input();
		ob.print();
		

	}

}
