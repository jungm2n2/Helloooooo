package com.score1;

public class Inform {
	
	String name,pan;
	double h,w;
	double bmi;
	

}
