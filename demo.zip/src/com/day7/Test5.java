package com.day7;





public class Test5 {

	public static void main(String[] args) {
		
		Sumyg d = new Sumyg();
		
		d.input();
		String pan = d.pan();
		d.print(pan);
		

	}

}
