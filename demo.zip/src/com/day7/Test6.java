package com.day7;

public class Test6 {

	public static void main(String[] args) {
		
		Order od = new Order();
		
		od.input();
		od.pan();
		od.print();
		
		

	}

}
