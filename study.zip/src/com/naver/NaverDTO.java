package com.naver;

public class NaverDTO {

	private String id;
	private String pw;
	private String name;
	private int yearSel;
	private int monthSel;
	private int daySel;
	private String genSel;
	private String email;
	private String numSel;
	private int putPhoneNum;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getYearSel() {
		return yearSel;
	}
	public void setYearSel(int yearSel) {
		this.yearSel = yearSel;
	}
	public int getMonthSel() {
		return monthSel;
	}
	public void setMonthSel(int monthSel) {
		this.monthSel = monthSel;
	}
	public int getDaySel() {
		return daySel;
	}
	public void setDaySel(int daySel) {
		this.daySel = daySel;
	}
	public String getGenSel() {
		return genSel;
	}
	public void setGenSel(String genSel) {
		this.genSel = genSel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNumSel() {
		return numSel;
	}
	public void setNumSel(String numSel) {
		this.numSel = numSel;
	}
	public int getPutPhoneNum() {
		return putPhoneNum;
	}
	public void setPutPhoneNum(int putPhoneNum) {
		this.putPhoneNum = putPhoneNum;
	}
	
	
	
	
}
