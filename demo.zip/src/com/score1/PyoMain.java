package com.score1;

public class PyoMain {

	public static void main(String[] args) {
		
		Pyo ob = new Pyo();
		
		ob.set();
		ob.input();
		ob.print();
		

	}

}
