package com.day18;

public interface Score {
	
	public void input();
	public void print();
	public void save();
	

}
