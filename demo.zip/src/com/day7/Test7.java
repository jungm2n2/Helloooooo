package com.day7;

public class Test7 {

	public static void main(String[] args) {
		
		Bigyo bg = new Bigyo();
		
		bg.input();
		bg.print();
		

	}

}
