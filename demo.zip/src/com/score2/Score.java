package com.score2;

public interface Score {
	
	public void set();
	public void input();
	public void print();
	

}
